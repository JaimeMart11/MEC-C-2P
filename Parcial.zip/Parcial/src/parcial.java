import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
public class Reloj extends JFrame implements ActionListener, ChangeListener {
    private final JLabel horaLabel;
    private final JButton iniciarButton;
    private final JButton detenerButton;
    private final JSlider velocidadSlider;
    private int velocidad;
    private final Timer timer;

    public Reloj() {
        super("Reloj");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        horaLabel = new JLabel("", JLabel.CENTER);
        horaLabel.setFont(new Font("Serif", Font.BOLD, 48));
        add(horaLabel, BorderLayout.CENTER);

        JPanel panel = new JPanel(new GridLayout(1, 3));
        JTextField horasTextField = new JTextField("00");
        JTextField minutosTextField = new JTextField("00");
        JTextField segundosTextField = new JTextField("00");
        panel.add(horasTextField);
        panel.add(minutosTextField);
        panel.add(segundosTextField);
        add(panel, BorderLayout.NORTH);

        JPanel panelBotones = new JPanel(new FlowLayout());
        iniciarButton = new JButton("Iniciar");
        iniciarButton.addActionListener(this);
        detenerButton = new JButton("Detener");
        detenerButton.addActionListener(this);
        detenerButton.setEnabled(false);
        panelBotones.add(iniciarButton);
        panelBotones.add(detenerButton);
        add(panelBotones, BorderLayout.SOUTH);

        velocidadSlider = new JSlider(JSlider.HORIZONTAL, -10, 10, 0);
        velocidadSlider.setMajorTickSpacing(5);
        velocidadSlider.setMinorTickSpacing(1);
        velocidadSlider.setPaintTicks(true);
        velocidadSlider.setPaintLabels(true);
        velocidadSlider.addChangeListener(this);
        add(velocidadSlider, BorderLayout.WEST);

        velocidad = 1;
        timer = new Timer(1000 / velocidad, this);
    }
}
