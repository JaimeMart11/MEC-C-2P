import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Reloj extends JFrame implements ActionListener {
    private final JTextField hora;
    private final JTextField minutos;
    private final JTextField segundos;
    private final JButton iniciar;
    private final JButton detener;
    private final JButton acelerar;
    private final JButton desacelerar;
    private int velocidad = 1000;
    private boolean detenido = true;

    public Reloj() {
        super("Reloj");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(2, 3));

        hora = new JTextField(2);
        hora.setEditable(false);
        add(hora);

        minutos = new JTextField(2);
        minutos.setEditable(false);
        add(minutos);

        segundos = new JTextField(2);
        segundos.setEditable(false);
        add(segundos);

        iniciar = new JButton("Iniciar");
        iniciar.addActionListener(this);
        add(iniciar);

        detener = new JButton("Detener");
        detener.addActionListener(this);
        add(detener);

        acelerar = new JButton("Acelerar");
        acelerar.addActionListener(this);
        add(acelerar);

        desacelerar = new JButton("Desacelerar");
        desacelerar.addActionListener(this);
        add(desacelerar);

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == iniciar) {
            detenido = false;
            Thread t = new Thread(new Runnable() {
                public void run() {
                    while (!detenido) {
                        try {
                            Thread.sleep(velocidad);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                        actualizarHora();
                    }
                }
            });
            t.start();
        } else if (e.getSource() == detener) {
            detenido = true;
        } else if (e.getSource() == acelerar) {
            velocidad /= 2;
        } else if (e.getSource() == desacelerar) {
            velocidad *= 2;
        }
    }

    private void actualizarHora() {
        java.util.Calendar calendario = java.util.Calendar.getInstance();
        hora.setText(String.format("%02d", calendario.get(java.util.Calendar.HOUR_OF_DAY)));
        minutos.setText(String.format("%02d", calendario.get(java.util.Calendar.MINUTE)));
        segundos.setText(String.format("%02d", calendario.get(java.util.Calendar.SECOND)));
    }

    public static void main(String[] args) {
        Reloj reloj;
        reloj = new Reloj();
    }
}

